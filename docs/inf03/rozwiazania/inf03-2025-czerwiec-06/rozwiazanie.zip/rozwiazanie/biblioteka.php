<?php
    $mysqli = mysqli_connect("localhost", "root", "", "biblioteka");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Biblioteka miejska</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <?php
                // Skrypt #1    
                for ($i = 0; $i < 20; $i++) {
                    echo '<img src="obraz.png" alt="grafika">';
                }
            ?>
        </header>

        <section id="pierwszy">
            <h2>Liryka</h2>
            <form action="biblioteka.php" method="post">
                <select name="liryka" id="liryka">
                    <?php
                        // Skrypt #2
                        $stmt = $mysqli->query('SELECT id, tytul FROM ksiazka WHERE gatunek = "liryka"');
                        if ($stmt) {
                            while ($row = $stmt->fetch_assoc()) {
                                $id = (int)$row['id'];
                                $title = $row['tytul'];
                                echo "<option value=\"{$id}\">{$title}</option>";
                            }
                            $stmt->free();
                        }
                    ?>
                </select>
                <input type="submit" value="Rezerwuj" name="buttonliryka" id='buttonliryka'>
            </form>
            <?php
                // Skrypt #3
                if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buttonliryka'], $_POST['liryka'])) {
                    $bookId = (int)$_POST['liryka'];
                    $title = null;

                    if ($stmt = $mysqli->prepare('SELECT tytul FROM ksiazka WHERE id = ?')) {
                        $stmt->bind_param('i', $bookId);
                        $stmt->execute();
                        $stmt->bind_result($title);
                        $stmt->fetch();
                        $stmt->close();
                    }

                    if ($title !== null) {
                        echo '<p>Książka '.$title.' została zarezerwowana</p>';

                        if ($update = $mysqli->prepare('UPDATE ksiazka SET rezerwacja = 1 WHERE id = ?')) {
                            $update->bind_param('i', $bookId);
                            $update->execute();
                            $update->close();
                        }
                    }
                }
            ?>
        </section>

        <section id="drugi">
            <h2>Epika</h2>
            <form action="biblioteka.php" method="post">
                <select name="epika" id="epika">
                    <?php
                        // Skrypt #2
                        $stmt = $mysqli->query('SELECT id, tytul FROM ksiazka WHERE gatunek = "epika"');
                        if ($stmt) {
                            while ($row = $stmt->fetch_assoc()) {
                                $id = (int)$row['id'];
                                $title = $row['tytul'];
                                echo "<option value=\"{$id}\">{$title}</option>";
                            }
                            $stmt->free();
                        }
                    ?>
                </select>
                <input type="submit" value="Rezerwuj" name="buttonepika" id='buttonepika'>
            </form>
            <?php
                // Skrypt #3
                if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buttonepika'], $_POST['epika'])) {
                    $bookId = (int)$_POST['epika'];
                    $title = null;

                    if ($stmt = $mysqli->prepare('SELECT tytul FROM ksiazka WHERE id = ?')) {
                        $stmt->bind_param('i', $bookId);
                        $stmt->execute();
                        $stmt->bind_result($title);
                        $stmt->fetch();
                        $stmt->close();
                    }

                    if ($title !== null) {
                        echo '<p>Książka '.$title.' została zarezerwowana</p>';

                        if ($update = $mysqli->prepare('UPDATE ksiazka SET rezerwacja = 1 WHERE id = ?')) {
                            $update->bind_param('i', $bookId);
                            $update->execute();
                            $update->close();
                        }
                    }
                }
            ?>
        </section>

        <section id="trzeci">
            <h2>Dramat</h2>
            <form action="biblioteka.php" method="post">
                <select name="dramat" id="dramat">
                    <?php
                        // Skrypt #2
                        $stmt = $mysqli->query('SELECT id, tytul FROM ksiazka WHERE gatunek = "dramat"');
                        if ($stmt) {
                            while ($row = $stmt->fetch_assoc()) {
                                $id = (int)$row['id'];
                                $title = $row['tytul'];
                                echo "<option value=\"{$id}\">{$title}</option>";
                            }
                            $stmt->free();
                        }
                    ?>
                </select>
                <input type="submit" value="Rezerwuj" name="buttondramat" id='buttondramat'>
            </form>
            <?php
                // Skrypt #3
                if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buttondramat'], $_POST['dramat'])) {
                    $bookId = (int)$_POST['dramat'];
                    $title = null;

                    if ($stmt = $mysqli->prepare('SELECT tytul FROM ksiazka WHERE id = ?')) {
                        $stmt->bind_param('i', $bookId);
                        $stmt->execute();
                        $stmt->bind_result($title);
                        $stmt->fetch();
                        $stmt->close();
                    }

                    if ($title !== null) {
                        echo '<p>Książka '.$title.' została zarezerwowana</p>';

                        if ($update = $mysqli->prepare('UPDATE ksiazka SET rezerwacja = 1 WHERE id = ?')) {
                            $update->bind_param('i', $bookId);
                            $update->execute();
                            $update->close();
                        }
                    }
                }
            ?>
        </section>

        <section id="czwarty">
            <h2>Zaległe książki</h2>
            <ul>
                <?php
                    // Skrypt #4
                    $result = $mysqli->query('SELECT tytul, id_cz, data_odd FROM ksiazka JOIN wypozyczenia ON id = id_ks ORDER BY data_odd LIMIT 15');
                    if ($result) {
                        while ($row = $result->fetch_assoc()) {
                            $title = $row['tytul'];
                            $readerId = (int)$row['id_cz'];
                            $returnDate = $row['data_odd'];
                            echo "<li>{$title} {$readerId} {$returnDate}</li>";
                        }
                        $result->free();
                    }
                ?>
            </ul>
        </section>

        <footer>
            <p><strong>Autor: <a href="https://ee-informatyk.pl/" target="_blank" style="text-decoration: none;color: unset;">EE-Informatyk.pl</a></strong></p>
        </footer>
    </body>
</html>

<?php
    $mysqli->close();
?>
<?php
    $conn = new mysqli("localhost", "root", "", "szkolenia");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Szkolenia i kursy</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header>
            <h1>SZKOLENIA</h1>
        </header>

        <main>
            <section id="lewo">
                <table>
                    <tr>
                        <th>Kurs</th>
                        <th>Nazwa</th>
                        <th>Cena</th>
                    </tr>
                    <?php
                        // Skrypt #1
                        $query = "SELECT kod, nazwa, cena FROM kursy ORDER BY cena;";
                        $result = $conn->query($query);
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td><img src='".$row['kod'].".jpg' alt='kurs'></td>";
                            echo "<td>" . $row['nazwa'] . "</td>";
                            echo "<td>" . $row['cena'] . "</td>";
                            echo "</tr>";
                        }
                    ?>
                </table>
            </section>

            <section id="prawo">
                <h2>Zapisy na kursy</h2>
                <form action="index.php" method="post">
                    <label for="imie">Imię</label><br>
                    <input type="text" name="imie" id="imie"><br>
                    <label for="nazwisko">Nazwisko</label><br>
                    <input type="text" name="nazwisko" id="nazwisko"><br>
                    <label for="wiek">Wiek</label><br>
                    <input type="number" name="wiek" id="wiek"><br>
                    <label for="kurs">Rodzaj kursu</label><br>
                    <select name="kurs" id="kurs">
                        <?php
                            // Skrypt #2
                            $query = "SELECT nazwa FROM kursy;";
                            $result = $conn->query($query);
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['nazwa'] . "'>" . $row['nazwa'] . "</option>";
                            }
                        ?>
                    </select><br>
                    <button type="submit">Dodaj dane</button>
                </form>
                <?php
                    // Skrypt #3
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        if($_POST['imie'] == "" || $_POST['nazwisko'] == "" || $_POST['wiek'] == "" || $_POST['kurs'] == "") {
                            echo "<p>Wypełnij wszystkie pola!</p>";
                        }
                        else {
                            $imie = $_POST['imie'];
                            $nazwisko = $_POST['nazwisko'];
                            $wiek = (int)$_POST['wiek'];
                            $kurs = $_POST['kurs'];

                            $stmt = $conn->prepare("INSERT INTO `uczestnicy`(`imie`, `nazwisko`, `wiek`) VALUES (?, ?, ?);");
                            $stmt->bind_param("ssi", $imie, $nazwisko, $wiek);
                            $stmt->execute();
                            $stmt->close();

                            echo "<p>Dane uczestnika $imie $nazwisko zostały dodane</p>";
                        }
                    }
                ?>
            </section>
        </main>

        <footer>
            <p>Stronę wykonał: <a href="https://ee-informatyk.pl/" target="_blank" style="text-decoration: none; color: unset;">EE-Informatyk.pl</a>
            </p>
        </footer>
    </body>
</html>

<?php
    $conn->close();
?>
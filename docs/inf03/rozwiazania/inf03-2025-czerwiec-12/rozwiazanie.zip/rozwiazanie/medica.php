<?php
    $conn = new mysqli("localhost", "root", "", "medica");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Przychodnia Medica</title>
        <link rel="stylesheet" href="styl.css">
        <link rel="shortcut icon" href="Obraz2.png" type="image/x-icon">
    </head>
    <body>
        <header>
            <h1>Abonamenty w przychodni Medica</h1>
        </header>

        <article>
            <?php
                // Skrypt #1
                $query = "SELECT nazwa, cena, opis FROM abonamenty;";
                $result = $conn->query($query);
                while($row = $result->fetch_assoc()) {
                    echo "<h3>" . $row['nazwa'] . " - " . $row['cena'] . " zł</h3>";
                    echo "<p>" . $row['opis'] . "</p>";
                    $row = $result->fetch_assoc();
                }
            ?>
            <a href="opis.html">Dowiedz się więcej</a>
        </article>

        <main>
            <section id="pierwszy">
                <h2>Standardowy</h2>
                <ul>
                    <?php
                        // Skrypt #2
                        $query = "SELECT nazwa, cecha FROM abonamenty JOIN szczegolyabonamentu ON abonamenty.id = Abonamenty_id JOIN cechy ON cechy.id = Cechy_id WHERE abonamenty.id = 1;";
                        $result = $conn->query($query);
                        while($row = $result->fetch_assoc()) {
                            echo "<li>" . $row['cecha'] . "</li>";
                        }
                    ?>
                </ul>
            </section>

            <section id="drugi">
                <h2>Premium</h2>
                <ul>
                    <?php
                        // Skrypt #2 zmodyfikowany dla abonamentu o id 2
                        $query = "SELECT nazwa, cecha FROM abonamenty JOIN szczegolyabonamentu ON abonamenty.id = Abonamenty_id JOIN cechy ON cechy.id = Cechy_id WHERE abonamenty.id = 2;";
                        $result = $conn->query($query);
                        while($row = $result->fetch_assoc()) {
                            echo "<li>" . $row['cecha'] . "</li>";
                        }
                    ?>
                </ul>
            </section>

            <section id="trzeci">
                <h2>Dziecko</h2>
                <ul>
                    <?php
                        // Skrypt #2 zmodyfikowany dla abonamentu o id 3
                        $query = "SELECT nazwa, cecha FROM abonamenty JOIN szczegolyabonamentu ON abonamenty.id = Abonamenty_id JOIN cechy ON cechy.id = Cechy_id WHERE abonamenty.id = 3;";
                        $result = $conn->query($query);
                        while($row = $result->fetch_assoc()) {
                            echo "<li>" . $row['cecha'] . "</li>";
                        }
                    ?>
                </ul>
            </section>
        </main>

        <footer>
            <p><img src="obraz2.png" alt="przychodnia">Stronę przygotował: <a href="https://ee-informatyk.pl/" target="_blank" style="text-decoration: none;color: unset;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>

<?php
    $conn->close();
?>
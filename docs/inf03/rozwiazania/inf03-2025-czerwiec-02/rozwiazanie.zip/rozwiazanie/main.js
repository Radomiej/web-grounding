const listaZadan = document.querySelector('main ul');
const poleZadania = document.getElementById('zadanie');
const przyciskDodaj = document.querySelector('nav button');

function oznaczJakoWykonane(event) {
	const elementListy = event.currentTarget.closest('li');
	if (elementListy) {
		elementListy.style.textDecoration = 'line-through';
	}
}

function podlaczPrzyciskiWykonane() {
	const przyciskiWykonane = listaZadan.querySelectorAll('button');
	przyciskiWykonane.forEach((przycisk) => {
		przycisk.addEventListener('click', oznaczJakoWykonane);
	});
}

function dodajZadanie() {
	const trescZadania = poleZadania.value.trim();
	if (!trescZadania) {
		return;
	}

	const nowyElement = document.createElement('li');
	nowyElement.textContent = trescZadania + ' ';

	const nowyPrzycisk = document.createElement('button');
	nowyPrzycisk.type = 'button';
	nowyPrzycisk.textContent = 'Wykonane';
	nowyPrzycisk.addEventListener('click', oznaczJakoWykonane);

	nowyElement.appendChild(nowyPrzycisk);
	listaZadan.appendChild(nowyElement);
	poleZadania.value = '';
}

przyciskDodaj.addEventListener('click', dodajZadanie);
podlaczPrzyciskiWykonane();
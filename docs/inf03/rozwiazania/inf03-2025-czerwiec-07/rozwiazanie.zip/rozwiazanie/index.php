<?php
    $conn = new mysqli("localhost", "root", "", "wyprawy");
?>

<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Biuro turystyczne</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="wczasy.html">Wczasy</a></li>
                <li><a href="wycieczki.html">Wycieczki</a></li>
                <li><a href="allinclusive.html">All inclusive</a></li>
            </ul>
        </nav>

        <main>
            <aside>
                <h3>Twój cel wyprawy</h3>
                <form action="index.php" method="post">
                    <label for="miejsce">Miejsce wycieczki</label><br>
                    <select name="miejsce" id="miejsce">
                        <?php
                            // Skrypt #1
                            $query = $conn->query("SELECT nazwa FROM miejsca ORDER BY nazwa");
                            if ($query && $query->num_rows) {
                                while ($row = $query->fetch_assoc()) {
                                    echo '<option value="'.$row['nazwa'].'">'.$row['nazwa'].'</option>';
                                }
                            }
                        ?>
                    </select><br>
                    <label for="dorosli">Ile dorosłych?</label><br>
                    <input type="number" name="dorosli" id="dorosli" min="1"><br>
                    
                    <label for="dorosli">Ile dzieci?</label><br>
                    <input type="number" name="dzieci" id="dzieci" min="1"><br>

                    <label for="termin">Termin</label><br>
                    <input type="date" name="termin" id="termin"><br>
                    <button type="submit" name="symulacja" id="symulacja">Symulacja ceny</button>
                </form>
                <h4>Koszt wycieczki</h4>
                <?php
                    // Skrypt #2
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $miejsce = $_POST['miejsce'];
                    $dorosli = max(0, (int)$_POST['dorosli']);
                    $dzieci = max(0, (int)$_POST['dzieci']);
                    $termin = $_POST['termin'];

                    if ($stmt = $conn->prepare("SELECT cena FROM miejsca WHERE nazwa = ?")) {
                        $stmt->bind_param("s", $miejsce);
                        if ($stmt->execute()) {
                            $stmt->bind_result($cena);
                            if ($stmt->fetch()) {
                                $koszt = $cena * $dorosli + ($cena * 0.5 * $dzieci);
                                echo '<p>W dniu: ' . $termin . '</p>';
                                echo '<p>' . $koszt . ' złotych</p>';
                            }
                        }
                        $stmt->close();
                    }
                }
                ?>
            </aside>

            <section>
                <h3>Wycieczki</h3>
                <?php
                    // Skrypt #3
                    $query = $conn->query('SELECT nazwa, cena, link_obraz FROM miejsca WHERE link_obraz LIKE "0%"');
                    while ($row = $query->fetch_assoc()) {
                        $nazwa = htmlspecialchars($row['nazwa'], ENT_QUOTES, 'UTF-8');
                        $cena = number_format((float)$row['cena'], 2, ',', ' ');
                        $obraz = htmlspecialchars($row['link_obraz'], ENT_QUOTES, 'UTF-8');
                        echo '<div class="wycieczka">';
                        echo '<img src="' . $obraz . '" alt="zdjęcie z wycieczki">';
                        echo '<h2>' . $nazwa . '</h2>';
                        echo '<p>' . $cena . ' zł</p>';
                        echo '</div>';
                    }
                ?>
            </section>
        </main>

        <footer>
            <p>Autor: <a href="https://ee-informatyk.pl/" target="_blank" style="color: unset;margin: unset;">EE-Informatyk.pl</a></p>
        </footer>
    </body>
</html>

<?php
    $conn->close();
?>